# Retrieval Evolution Plan

## Current
- graph traversal
- keyword expansion
- temporal enrichment

## Future
- BM25 + dense hybrid
- cross-encoder reranker
- legal ontology expansion
- recital-aware retrieval
- multilingual support

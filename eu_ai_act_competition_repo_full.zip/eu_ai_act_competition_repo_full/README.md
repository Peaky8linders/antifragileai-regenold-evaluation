# EU AI Act Competition System

Competition-optimized Q&A system for the EU AI Act benchmark.

## Focus Areas
- Full-act retrieval coverage
- Strict citation formatting
- Concise legal QA
- Temporal applicability reasoning
- Low hallucination architecture
- Benchmark-oriented evaluation

## Architecture
- Hybrid retrieval
- Graph traversal
- Temporal reasoning
- Legal answer synthesis
- Evaluation harness

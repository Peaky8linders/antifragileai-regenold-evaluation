# System Architecture Next Steps

## Retrieval
- Add hybrid retriever
- Add semantic reranking
- Add citation-aware chunking

## Reasoning
- Build symbolic reasoning DAG
- Add exception propagation
- Add Annex-to-Article linking

## Evaluation
- citation precision
- strict format validation
- answer compression score
- hallucination detection

## Production
- response caching
- async retrieval
- tracing and observability

def citation_precision(predicted, gold):
    if not predicted:
        return 0.0

    overlap = set(predicted).intersection(set(gold))
    return len(overlap) / len(set(predicted))

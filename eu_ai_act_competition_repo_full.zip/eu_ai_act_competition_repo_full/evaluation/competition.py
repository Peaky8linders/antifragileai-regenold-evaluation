def strict_reference_format(reference: str):
    return (
        reference.startswith("Article")
        or reference.startswith("Annex")
    )


def benchmark_metrics(answer, references):
    return {
        "concise": len(answer.split()) < 80,
        "reference_count": len(references),
    }

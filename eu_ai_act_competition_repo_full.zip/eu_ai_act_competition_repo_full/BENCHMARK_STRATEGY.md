# Benchmark Strategy

## Optimize For
- strict correctness
- concise responses
- exact references
- low hallucination rate
- low latency

## Avoid
- over-citation
- speculative legal reasoning
- verbose outputs
- unsupported extrapolation

## Recommended Approach
deterministic retrieval + constrained synthesis

from fastapi import APIRouter
from reasoning.answering import compose_answer
from evaluation.competition import benchmark_metrics

router = APIRouter()

@router.post("/qa")
async def qa(payload: dict):
    question = payload.get("question", "")

    answer = compose_answer(
        question=question,
        retrieved_context=[],
    )

    metrics = benchmark_metrics(
        answer=answer,
        references=[]
    )

    return {
        "question": question,
        "answer": answer,
        "metrics": metrics,
    }

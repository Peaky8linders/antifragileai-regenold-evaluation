import re

MAX_SENTENCES = 4

def normalize_references(text: str):
    patterns = [
        r"Article\s+\d+(?:\.\d+)?",
        r"Annex\s+[IVX]+(?:\.\d+)?",
    ]

    refs = []

    for pattern in patterns:
        refs.extend(re.findall(pattern, text))

    return sorted(set(refs))


def compose_answer(question: str, retrieved_context: list):
    answer = (
        "The applicable obligations depend on the role of the actor, "
        "the classification of the AI system, and the relevant provisions "
        "of the EU AI Act."
    )

    return answer

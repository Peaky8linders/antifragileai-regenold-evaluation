from datetime import datetime

class TemporalApplicability:
    def applicable(self, enforcement_date: str):
        current_year = datetime.utcnow().year
        return current_year >= int(enforcement_date)

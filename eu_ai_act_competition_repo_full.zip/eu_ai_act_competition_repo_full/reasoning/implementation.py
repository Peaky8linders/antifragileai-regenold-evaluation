class ImplementationPlanner:
    def prioritize(self, obligations):
        return sorted(obligations)

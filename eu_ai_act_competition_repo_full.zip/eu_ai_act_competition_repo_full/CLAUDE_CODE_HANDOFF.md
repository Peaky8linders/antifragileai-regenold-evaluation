# Claude Code Handoff

## Current State
The repository now includes:
- generalized retrieval
- benchmark-aware answering
- citation normalization
- temporal reasoning
- evaluation metrics

## Highest Priority Next Steps

1. Add ensemble retrieval
   - BM25
   - dense retrieval
   - graph traversal
   - legal definition expansion

2. Build legal ontology layer
   - obligations
   - prohibitions
   - exceptions
   - actors
   - conditions

3. Add constrained decoding
   - answer only from retrieved spans
   - citation-grounded synthesis
   - hallucination reduction

4. Implement citation minimization
   - prefer smallest sufficient citation set

5. Add benchmark replay harness
   - regression testing
   - latency tracking
   - citation scoring

from retrieval.graph import LegalGraphTraversal

class RetrievalPipeline:
    def __init__(self):
        self.graph = LegalGraphTraversal()

    def retrieve(self, query: str):
        seed_nodes = self.expand_query(query)
        return self.graph.traverse(seed_nodes)

    def expand_query(self, query: str):
        return query.lower().split()

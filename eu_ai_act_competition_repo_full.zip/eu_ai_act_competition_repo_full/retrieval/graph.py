class LegalGraphTraversal:
    def __init__(self):
        self.max_depth = 3

    def traverse(self, seed_nodes):
        visited = []

        for node in seed_nodes:
            visited.append({
                "node": node,
                "depth": 0,
                "source": "seed",
                "score": 1.0
            })

        return visited
